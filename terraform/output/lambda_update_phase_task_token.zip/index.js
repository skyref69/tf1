"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LambdaUpdatePhaseTaskTokenFunction = void 0;
const aws_sdk_1 = require("aws-sdk");
const dynamodb_1 = require("aws-sdk/clients/dynamodb");
const process = require("process");
const dynamoClient = new aws_sdk_1.DynamoDB({});
const LambdaUpdatePhaseTaskTokenFunction = async (event) => {
    if (!event)
        return sendFail("invalid request: body undefined !");
    if (!event.token)
        return sendFail("invalid request: token undefined !");
    const id = event.otherInput.dataOpened.id;
    const taskToken = event.token;
    let TableName = process.env.databasename;
    try {
        const todoParams = {
            Key: dynamodb_1.Converter.marshall({ id: id }),
            UpdateExpression: "set taskToken = :taskToken",
            ConditionExpression: "attribute_exists(id)",
            ExpressionAttributeValues: dynamodb_1.Converter.marshall({ ":taskToken": taskToken, }),
            ReturnValues: "ALL_NEW",
            TableName: TableName
        };
        const { Attributes } = await dynamoClient.updateItem(todoParams).promise();
        const todo = Attributes ? dynamodb_1.Converter.unmarshall(Attributes) : null;
        return {
            statusCode: 200,
            body: JSON.stringify({ todo })
        };
    }
    catch (err) {
        console.error(err);
        return sendFail("something went wrong");
    }
};
exports.LambdaUpdatePhaseTaskTokenFunction = LambdaUpdatePhaseTaskTokenFunction;
const sendFail = (message) => {
    return message;
};
